#pragma once
#ifndef CPU_CODE_H
#define CPU_CODE_H

#include <vector>

void computeSumCPU(const std::vector<float>& TAB, std::vector<float>& OUT, int N, int R);

#endif
